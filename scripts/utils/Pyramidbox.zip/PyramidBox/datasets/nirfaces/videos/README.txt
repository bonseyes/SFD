1. Download all 60 videos by download all .tar files from https://www.dropbox.com/sh/a15a7nrf7hmhmvy/AADoSpRB0BzU98Z_PC8K1wNQa
2. Unpack tar files into this folder : Sub1.avi, Sub2.avi, etc
3. Run capture_frames.py on each video to create images for processing:

python capture_frames.py --input Sub1 --format .avi --outdir ../images
python capture_frames.py --input Sub2 --format .avi --outdir ../images
..