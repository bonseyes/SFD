import os
import json
import time
import warnings
import argparse
import cv2

# Usage : python capture_frames.py --input Sub1 --format .avi --outdir ../images

parser = argparse.ArgumentParser()
parser.add_argument('--input', default='Sub1')
parser.add_argument('--outdir', default='../images')
parser.add_argument('--format', default='.avi')
args = parser.parse_args()

video = args.input + args.format
vidcap = cv2.VideoCapture(video)
success,image = vidcap.read()
count = 0
while success:
  cv2.imwrite(args.outdir + "/%s_frame_%d.jpg" % (args.input, count), image)     # save frame as JPEG file      
  success,image = vidcap.read()
  print('Read a new frame: ', success)
  count += 1